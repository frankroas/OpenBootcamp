public class Main {
    public static void main(String[] args) {
        int resultado = 0;
        resultado = suma(1 ,2, 3);
        System.out.println(resultado);

        Coche micoche = new Coche();
        micoche.SumarPuertas();
        System.out.println("El choche tiene "+micoche.puertas+" puertas.");
    }
    public static int suma(int a, int b, int c){
        return a + b + c;
    }
}

class Coche{
    public int puertas = 2;

    public void SumarPuertas(){
        this.puertas++;
    }
}